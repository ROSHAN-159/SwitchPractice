package com.LMS.LibraryManagementSystem.ServiceTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.annotation.Rollback;

import com.LibraryManegementSystem.Exception.UserNotFoundException;
import com.LibraryManegementSystem.repository.UserRepository;
import com.LibraryManegementSystem.security.services.UserDetailsServiceImpl;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

	@Mock
	private UserRepository repo;

	private UserDetailsServiceImpl service;

	@BeforeEach
	void setUp() {
		this.service = new UserDetailsServiceImpl();
	}

	@Test
	@Order(1)
	@Rollback(false)
	void viewAllUsersTest() {
		service.getAllUser();
		verify(repo).findAll();
	}

	@Test
	@Order(2)
	@Rollback(false)
	void deleteUserByIdTest() {
		try {
			service.deleteUser(1l);
		} catch (UserNotFoundException e) {
			e.printStackTrace();
		}
		verify(repo).deleteById(1l);
	}

	@Test
	@Order(3)
	@Rollback(false)
	void findbyusername() {
		service.loadUserByUsername("Roshan");
		try {
			verify(repo).findByUsername("Roshan");			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
}
