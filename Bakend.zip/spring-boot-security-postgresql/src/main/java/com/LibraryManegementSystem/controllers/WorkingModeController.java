package com.LibraryManegementSystem.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.LibraryManegementSystem.Exception.FeedbackNotFoundException;
import com.LibraryManegementSystem.models.Feedback;
import com.LibraryManegementSystem.models.WorkModeType;
import com.LibraryManegementSystem.security.services.FeedbackService;
import com.LibraryManegementSystem.security.services.WorkingTypeService;

@RestController
@CrossOrigin(origins = "*", maxAge = 9000)
@RequestMapping("/api/test")
public class WorkingModeController {

	@Autowired
	private WorkingTypeService serr;
	
	
	@GetMapping("/getAllWorkMode")
	public List<WorkModeType> viewFeedbackList() {
		return serr.getallmode();
	}

	
	
	@PostMapping("/add")
	public String saveWorkingType(@RequestBody WorkModeType modeType) {
		return serr.saveWorkingType(modeType);
	}
}