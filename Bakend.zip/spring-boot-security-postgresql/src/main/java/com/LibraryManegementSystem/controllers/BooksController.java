package com.LibraryManegementSystem.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.LibraryManegementSystem.Exception.BookNotFoundException;
import com.LibraryManegementSystem.models.Books;
import com.LibraryManegementSystem.security.services.BooksService;

@RestController
@CrossOrigin(origins = "*", maxAge =9000)
@RequestMapping("/api/test")
public class BooksController {

	@Autowired
	BooksService b;

	@GetMapping("/getbooks")
	public List<Books> viewAllBooks() throws BookNotFoundException {
		return b.viewAllBooks();
	}

	@GetMapping("/getbooksby/title/{title}")
	public List<Books> searchBookByTitle(@PathVariable String title) throws BookNotFoundException {
		return b.searchBookByTitle(title);
	}

	@GetMapping("/getbooksby/subject/{subject}")
	public List<Books> searchBookBySubject(@PathVariable String subject) throws BookNotFoundException {
		return b.searchBookBySubject(subject);
	}
	@GetMapping("/getbooks/{bookid}")
	public Books searchBookBySubject(@PathVariable int bookid) throws BookNotFoundException {
		return b.getbyid(bookid);
	}

	@PostMapping("/postbooks")
	public int addbook(@RequestBody Books book) {
		return b.addBook(book);
	}

	@PutMapping("/putbooks/{bookid}")
	public int updateBookDetails(@PathVariable int bookid, @RequestBody Books book) throws BookNotFoundException {
		return b.updateBookDetails(bookid, book);
	}

	@DeleteMapping("/deletebooks/{bookId}")
	private int removeBook(@PathVariable int bookId) throws BookNotFoundException {
		return b.removeBook(bookId);

	}

}
