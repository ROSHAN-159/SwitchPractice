package com.LibraryManegementSystem.security.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LibraryManegementSystem.models.BooksReturned;
import com.LibraryManegementSystem.repository.BooksReturnedRepository;

@Service
public class BooksReturnedService {
	private static final Logger log = LoggerFactory.getLogger(BooksReturnedService.class);

	@Autowired
	BooksReturnedRepository repo;

	

	public int returnBook(BooksReturned returned) {
		log.info("Returning Book...");
		try {
			repo.save(returned);
			log.info("Book Returned!!");
			return 1;
		} catch (Exception e) {
			return 0;
		}

	}

	public int updateReturnedBookDetails(BooksReturned booksReturned) {
		log.info("Updating Returned Book...");
		try {
			repo.save(booksReturned);
			log.info("Updated Returned Book");
			return 1;
		} catch (Exception e) {
			return 0;
		}
	}

	public List<BooksReturned> viewReturnedBooksList() {
		try {
			log.info("Fetching Returned Book...");
			return (List<BooksReturned>) repo.findAll();
		} catch (Exception e) {
			return null;
		}
	}

//	public List<BooksReturned> viewDelayedBooksList() {
//		List<BooksReturned> breturned = (List<BooksReturned>) repo.findAll();
//		int limit = 15;
//		for (BooksReturned b : breturned) {
//			if (b.getDelayed_Days() > limit) {
//				return (List<BooksReturned>) b.getUsers();
//			}
//		}
//		return null;
//	}
	
	public BooksReturnedService(BooksReturnedRepository repo2) {
		super();}
}