package com.LibraryManegementSystem.security.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LibraryManegementSystem.Exception.AuthorNotFoundException;
import com.LibraryManegementSystem.models.Author;
import com.LibraryManegementSystem.repository.AuthorRepository;

@Service
public class AuthorService {
	private static final Logger log = LoggerFactory.getLogger(AuthorService.class);
	@Autowired
	private AuthorRepository repo;

	public int addAuthorDetails(Author author) throws AuthorNotFoundException {
		log.info("Adding Author Details...");
		try {
			repo.save(author);
			log.info("Added Author Details!!");
			return 1;
		} catch (Exception e) {
			throw new AuthorNotFoundException("Unable to add Author!!");
		}
	}

	public int updateAuthorDetails(Author author) throws AuthorNotFoundException {
		log.info("Updating Author Details...");
		try {
			repo.save(author);
			log.info("Author Details Updated!!");
			return 1;
		} catch (Exception e) {
			throw new AuthorNotFoundException("Author Not Found!!");
		}
	}

	public int deleteAuthorDetails(int authorid) throws AuthorNotFoundException {
		log.info("Removing Author Details...");
		try {
			repo.deleteById(authorid);
			log.info("Author Details Removed!!");
			return 1;
		} catch (Exception e) {
			throw new AuthorNotFoundException("Author with given ID Not Found!!");
		}
	}

	public List<Author> viewAuthorList() {
		List<Author> rk = new ArrayList<>();
		try {
			return (List<Author>) repo.findAll();
		} catch (Exception e) {
			return rk;
		}
	}

	public Author viewAuthorById(int id) throws AuthorNotFoundException {
		try {
			Optional<Author> author = repo.findById(id);
			if (author.isPresent()) {
				return author.get();
			}
		} catch (Exception e) {
			throw new AuthorNotFoundException("Author Not Found!!");
		}
		return null;
	}

	public AuthorService(AuthorRepository repo) {
		super();
		this.repo = repo;
	}

}