package com.LibraryManegementSystem.security.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.LibraryManegementSystem.models.DamagedBooks;
import com.LibraryManegementSystem.repository.DamagedBooksRepository;

@Service
public class DamagedBooksService {

	private static final Logger log = LoggerFactory.getLogger(DamagedBooksService.class);

	@Autowired
	private DamagedBooksRepository repo;

	public int addDamagedBooks(DamagedBooks damagedbooks) {
		DamagedBooks books = new DamagedBooks();

		books.setQuantity(damagedbooks.getQuantity());
		books.setDescription(damagedbooks.getDescription());
		books.setStatus("Damaged");
		log.info("Adding Damaged Book...");
		try {
			repo.save(books);
			log.info("Damaged Book Added!!");
			return 1;
		} catch (Exception e) {
			return 0;
		}
	}

	public int updateDamagedBookDetails(int id, DamagedBooks damagebook) {
		DamagedBooks books = repo.findById(id).get();

		books.setQuantity(damagebook.getQuantity());
		books.setDescription(damagebook.getDescription());
		books.setStatus("Restored");
		log.info("Updating Damaged Book Details...");
		try {
			repo.save(books);
			log.info("Damaged Book Details Updated!!");
			return 1;
		} catch (Exception e) {
			return 0;
		}
	}

	public List<DamagedBooks> viewDamagedBooksList() {
		List<DamagedBooks> lst = null;
		try {
			log.info("Fetching Damaged Book Details...");
			lst = (List<DamagedBooks>) repo.findAll();
			log.info("Fetched Damaged Book Details!!");
			return lst;
		} catch (Exception e) {
			return lst;
		}
	}

	public DamagedBooks viewDamegedBooksById(int damagedid) {
		DamagedBooks d = null;
		try {
			log.info("Fetching Damaged Book Details for id " + damagedid);
			d = repo.findById(damagedid).get();
			log.info("Details fetched!!");
			return d;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return d;
		}
	}

	public DamagedBooksService(DamagedBooksRepository repo) {
		super();
		this.repo = repo;

	}
}
