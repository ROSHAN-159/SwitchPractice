package com.LibraryManegementSystem.models;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name =  "feedddd")
public class Feedback {

	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long feedbackid;

	
	@Column
	private LocalDate feedbackDate;

	@Column
	private String description;

	@Column
	private String rating;

	@Column
	private String comments;

	@ManyToOne
	private User user; 
	
//	@Column 
//	private int userid;
	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}

public Feedback(Long feedbackid, LocalDate feedbackDate, String description, String rating, String comments,
		User user) {
	super();
	this.feedbackid = feedbackid;
	this.feedbackDate = feedbackDate;
	this.description = description;
	this.rating = rating;
	this.comments = comments;
	this.user = user;
}

public Long getFeedbackid() {
	return feedbackid;
}

public void setFeedbackid(Long feedbackid) {
	this.feedbackid = feedbackid;
}

public LocalDate getFeedbackDate() {
	return feedbackDate;
}

public void setFeedbackDate(LocalDate feedbackDate) {
	this.feedbackDate = feedbackDate;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

public String getRating() {
	return rating;
}

public void setRating(String rating) {
	this.rating = rating;
}

public String getComments() {
	return comments;
}

public void setComments(String comments) {
	this.comments = comments;
}

public User getUser() {
	return user;
}

public void setUser(User user) {
	this.user = user;
}


}
