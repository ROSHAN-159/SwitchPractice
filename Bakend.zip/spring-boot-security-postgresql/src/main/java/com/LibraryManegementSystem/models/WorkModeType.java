package com.LibraryManegementSystem.models;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;


@Entity
public class WorkModeType {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Id;

	@Column
	private String WorkmodeType;
	
	@Column
	private String Status;

	@Column
	private LocalDate LocalDate;
	
//	@ManyToOne
//	public User user;
	@Column
	private int UserID;
	
	public WorkModeType() {
		// TODO Auto-generated constructor stub
	}

	public WorkModeType(int id, String workmodeType, String status, java.time.LocalDate localDate, int userID) {
		super();
		Id = id;
		WorkmodeType = workmodeType;
		Status = status;
		LocalDate = localDate;
		UserID = userID;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getWorkmodeType() {
		return WorkmodeType;
	}

	public void setWorkmodeType(String workmodeType) {
		WorkmodeType = workmodeType;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public LocalDate getLocalDate() {
		return LocalDate;
	}

	public void setLocalDate(LocalDate localDate) {
		LocalDate = localDate;
	}

	public int getUserID() {
		return UserID;
	}

	public void setUserID(int userID) {
		UserID = userID;
	}


}