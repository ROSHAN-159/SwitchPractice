package com.LibraryManegementSystem.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.LibraryManegementSystem.models.BooksIssued;

@Repository
public interface BooksIssuedRepository extends CrudRepository<BooksIssued,Integer>{



}
