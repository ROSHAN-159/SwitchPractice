package com.LibraryManegementSystem.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.LibraryManegementSystem.models.Publishers;

@Repository
public interface PublisherRepository extends CrudRepository<Publishers, Integer> {

}
