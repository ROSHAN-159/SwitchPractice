package com.LibraryManegementSystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.LibraryManegementSystem.models.WorkModeType;

@Repository
public interface WorkingModeReposistory extends JpaRepository<WorkModeType, Integer> {

//	public WorkModeType findByWorkmodeType(String id);
}
