//package com.LibraryManegementSystem.repository;
//
//import javax.transaction.Transactional;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.repository.CrudRepository;
//import org.springframework.stereotype.Repository;
//
//import com.LibraryManegementSystem.models.Books;
//import com.LibraryManegementSystem.models.BooksOrder;
//
//@Repository 
//public interface BooksOrderRepository extends JpaRepository<BooksOrder,Integer>{
//
//	Books findByBooks_Bookid(int id);
//	
//	Books deleteByBooks_Bookid(int id);
//	
//}
