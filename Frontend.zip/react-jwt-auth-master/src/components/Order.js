import React, { Component } from "react";
import axios from "axios";
import authHeader from "../services/auth-header";

export default class Order extends Component {
  constructor(props) {
    super(props);

    this.state = {
      orderDate: "",
      orderStatus: "",
      quantity: "",
      order: [],
    }
  }

  componentDidMount() {
    axios
      .get("http://localhost:8090/api/test/getorderbooks", {
        headers: authHeader(),
      })
      .then((response) => {
        this.setState({ order: response.data });
      });
  }
  
    handleSubmit = (e) => {
      e.preventDefault();
      console.log(this.state);
      axios
      .post("http://localhost:8090/api/test/postorderbooks", this.state)
      .then((res) => {
        alert("Order Succesfully");
       
        console.log("User Registered");
      })
      .catch((error) => {
        window.location.reload(false);
      });
  };
  handler = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  deletebook = (orderid) => {
    axios
      .delete("http://localhost:8090/api/test/deletebooksOrder/" + orderid, {
        headers: authHeader(),
      })
      .then(
        (response) => {
          alert("Order Removed");
          window.location.reload(false);
        },
        (error) => {
          window.location.reload(false);
          alert("Operation failed");
        }
      );
  };

  placedOrder = (orderid) => {
    axios
      .put("http://localhost:8090/api/test/placedorder/byid/" + orderid, {
        headers: authHeader(),
      })
      .then(
        (response) => {
          alert("Order Confirmed");
          window.location.reload(false);
        },
        (error) => {
          alert("Operation failed");
        }
      );
  };
  render() {
    return (
      <>
        <div className="regi"></div>
        <div>
          <div>
          <h3 style={{textAlign:"center"}}>All Orders</h3>
            <table className="table table-striped">
              <thead class="table-warning">
                <tr>
                  <th scope="col">Order Id</th>
                  <th scope="col">Quantity</th>
                  <th scope="col">Order Date</th>
                  <th scope="col"> Order Status </th>
                  <th scope="col"> Placed Status </th>
                  <th scope="col"> Remove Order </th>.
                </tr>
              </thead>
              <tbody>
                {this.state.order.map((c) => (
                  <tr key={c.orderid}>
                    <td>{c.orderid}</td>
                    <td>{c.quantity} </td>
                    <td>{c.orderDate}</td>
                    <td>{c.orderStatus}</td>
                    <td>
                      <button
                        type="button"
                        class="btn btn-info"
                      ref={this.buttonRef}
                        onClick={() => {
                          this.placedOrder(c.orderid);
                        }}
                      >
                        Confirm Order
                      </button>
                    </td>
                
                    <td>
                      <button
                        type="button"
                        class="btn btn-danger "
                        onClick={() => {
                          this.deletebook(c.orderid);
                        }}
                      >
                        Cancel Order
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </>
    );
  }
}
