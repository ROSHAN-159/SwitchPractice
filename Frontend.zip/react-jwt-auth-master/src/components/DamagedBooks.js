import React, { Component } from "react";
import axios from "axios";

import authHeader from "../services/auth-header";

export default class DamagedBooks extends Component {
  constructor(props) {
    super(props);

    this.state = {
      quantity: '',
      description: '',
      m: [],
    };
  }

  componentDidMount() {
    axios
      .get("http://localhost:8090/api/test/viewDamagedBooksList", { headers: authHeader() })
      .then((response) => {
        this.setState({ m: response.data });
      });
  }

  
  restore = (bookid) => {
    axios
      .put("http://localhost:8090/api/test/updateDamagedBookDetails/" + bookid, {
        headers: authHeader(),
      })
      .then(
        (response) => {
          alert("Restored Succesfully");
          window.location.reload(false);
        },
        (error) => {
          alert("Operation failed");
        }
      );
  };

  render() {

    return (
      <>
        <div>
          <div>
          <h3 style={{textAlign:"center"}}>Damaged Books</h3>
            <table className="table table-Primary">
              <thead class="table-danger">
                <tr>
                  <th scope="col">DamagedBook Id</th>
                  <th scope="col">Quantity</th>
                  <th scope="col"> Description </th>
                  <th scope="col">Status</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                {this.state.m.map((c) => (

                  <tr key={c.damagedid}>
                    <td>{c.damagedid}</td>
                    <td>{c.quantity} </td>
                    <td>{c.description}</td>
                    <td>{c.status}</td>
                    <td>
                      <button
                        type="button"
                        class="btn btn-secondary"
                        onClick={() => {
                          this.restore(c.damagedid);
                        }}
                      >
                       Re Store
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </>
    );
  }
}
