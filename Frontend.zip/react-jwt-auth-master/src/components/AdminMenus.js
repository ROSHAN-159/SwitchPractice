import React, { Component } from "react";

import im from "../image/logo.jpg"
import {  Link } from "react-router-dom";
export default class AdminMenus extends Component {
  render() {
    return (
      <div>
        <div className="card text-center" style={{marginTop:"10px", backgroundColor:"grey"}} >
          <div className="card-header" id="admintab">
            <ul className="nav nav-tabs card-header-tabs" >
              <li className="nav-item">
                <Link
                  className="nav-link active"
                  aria-current="true"
                  to="/users">
                  Users
                </Link>
              </li>
              
              <li className="nav-item">
                <Link
                  className="nav-link active"
                  aria-current="true"
                  to="/books">
                  Available Books
                </Link>
              </li>

              <li className="nav-item">
                <Link
                  className="nav-link active"
                  aria-current="true"
                  to="/damagedbooks">
                  Damaged Books
                </Link>
              </li>

              <li className="nav-item">
                <Link
                  className="nav-link active"
                  aria-current="true"
                  to="/order">
                 Orders
                </Link>
              </li>

              <li className="nav-item">
                <Link
                  className="nav-link active"
                  aria-current="true"
                  to="/publisher">
                 Publisher
                </Link>
              </li>

              <li className="nav-item">
                <Link
                  className="nav-link active"
                  aria-current="true"
                  to="/suggestedbooks">
                 Suggested Books
                </Link>
              </li>

              <li className="nav-item">
                <Link
                  className="nav-link active"
                  aria-current="true"
                  to="/feedback">
                Feedback List
                </Link>
              </li>
              <li className="nav-item">
                <Link
                  className="nav-link active"
                  aria-current="true"
                  to="/author">
                Authors 
                </Link>
              </li>
              <li className="nav-item">
                <Link
                  className="nav-link active"
                  aria-current="true"
                  to="/issuedbooks">
                Issued List 
                </Link>
              </li>
            </ul>
          </div>
       <img src={im} style={{height:"500px"}}/>
        </div>
      </div>
    );
  }
}
