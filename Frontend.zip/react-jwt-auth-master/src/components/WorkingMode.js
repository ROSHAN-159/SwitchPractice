import React, { Component } from 'react';
import axios from 'axios';
import AuthService from "../services/auth.service";

export default class WorkingMode extends Component {
  state = {
    curDT: new Date().toLocaleString(),
    id: null,
    date: "",
    workmodeType: "", // Separate keys for work mode types
    currentUser: null, // Initialize currentUser in state
    userId: currentUser,
  };

  componentDidMount() {
    const currentUser = AuthService.getCurrentUser();
    this.setState({ currentUser, userId: currentUser.id }); // Set currentUser and userId
  }

  handleSubmit = (workmodeType) => {
    this.setState({ workmodeType }, () => {
      axios.post("http://localhost:8090/api/test/add", this.state)
        .then((res) => {
          window.location.reload(false);
          console.log("Checked in submitted");
        })
        .catch(error => console.error("Error:", error));
    });
  };

  render() {
    const { currentUser } = this.state;

    return (
      <div>
        <button type="button" className="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
          Check in
        </button>
       
        <div className="modal fade" id="exampleModal" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h1 className="modal-title fs-5" id="exampleModalLabel">Work From Office/Home</h1>
                {currentUser && currentUser.id} {/* Check if currentUser exists */}
                <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              
              <div className="modal-body">
                Today Date : {this.state.curDT}
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-primary" data-bs-dismiss="modal" onClick={() => this.handleSubmit("Work From Home")}>WFH</button>
                <button type="button" className="btn btn-success" data-bs-dismiss="modal" onClick={() => this.handleSubmit("Work From Office")}>WFO</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
