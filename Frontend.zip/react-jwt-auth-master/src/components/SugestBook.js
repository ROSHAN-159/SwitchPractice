import React, { Component } from 'react'
import axios from 'axios';
import authHeader from '../services/auth-header';
export default class SugestBook extends Component {
  constructor(props) {
    super(props);

    var today = new Date(),
    date = today.getFullYear() + '-' +'0'+ (today.getMonth() + 1) + '-' + today.getDate();
    this.state = {
      title: "",
      subject: "",
      author: "",
      publications: "",
      description: "",
      suggested_date: date,
      status: "",
      m: [],
    };
  }
  componentDidMount() {
    axios
      .get("http://localhost:8090/api/test/getSuggestedBooks", { headers: authHeader() })
      .then((response) => {
        this.setState({ m: response.data });
      });
    }

  handleSubmit = (e) => {
    e.preventDefault();
    console.log(this.state);
    axios
      .post("http://localhost:8090/api/test/addSuggestedBooks", this.state)
      .then((res) => {
        alert("Suggested Succesfully");
        window.location.reload(false);
        console.log("Suggestion Registered");
      })
      .catch((error) => {});
  };

  handler = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  
  render() {
    return (
      <div>  <div className="regi">
      <form>
        <div className="row">
          <div className="col">
            <input
              style={{ marginBottom: "9px" }}
              type="text"
              className="form-control"
              placeholder="title "
              value={this.state.title}
              name="title"
              onChange={this.handler}
            />
            <input
              style={{ marginBottom: "9px" }}
              type="text"
              className="form-control"
              placeholder="subject "
              value={this.state.subject}
              name="subject"
              onChange={this.handler}
            />
             <input
              style={{ marginBottom: "9px" }}
              type="text"
              className="form-control"
              placeholder="publications "
              value={this.state.publications}
              name="publications"
              onChange={this.handler}
            />
       

          </div>

          <div className="col">
        
            <input
              style={{ marginBottom: "9px" }}
              type="text"
              className="form-control"
              placeholder=" description"
              value={this.state.description}
              name="description"
              onChange={this.handler}
            />

<input
              style={{ marginBottom: "9px" }}
              type="text"
              className="form-control"
              placeholder="author "
              value={this.state.author}
              name="author"
              onChange={this.handler}
            />


          </div>
        </div>
        <div class="text-center" id="btns">
          <button
            type="button"
            class="btn btn-primary "
            onClick={this.handleSubmit}
          >
            Suggest Book
          </button>
        </div>
      </form>
       
     <div>
            <table className="table table-striped">
              <thead class="table-success">
                <tr>
                  <th scope="col">Book Id</th>
                  <th scope="col">Title</th>
                  <th scope="col">Subject</th>
                  <th scope="col"> Author </th>
                  <th scope="col"> Publications </th>
                  <th scope="col">Description </th>
                  <th scope="col">Date </th>
                  <th scope="col"> Status </th>
                </tr>
              </thead>
              <tbody>
                {this.state.m.map((c) => (
                  <tr key={c.id}>
                    <td>{c.id}</td>
                    <td>{c.title} </td>
                    <td>{c.subject}</td>
                    <td>{c.author}</td>
                    <td>{c.publications}</td>
                    <td>{c.description}</td>
                    <td>{c.suggested_date}</td>
                    <td>{c.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
    </div></div>
    )
  }
}
