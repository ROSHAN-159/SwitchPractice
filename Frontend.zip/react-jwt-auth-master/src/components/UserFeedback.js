import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";

import authHeader from "../services/auth-header";
export default function UserFeedback() {
  const { id } = useParams();
  const [feedback, fetchfeedback] = useState({
    description: "",
    comments: "",
    rating: "",
  });

  const onInputChange = e => {
    fetchfeedback({...feedback,[e.target.name]: e.target.value });
  };


  const onSubmit = async e => {
    e.preventDefault();
    await axios.post(`http://localhost:8090/api/test/addfeedback/${id}`, feedback ,{headers:authHeader(),});
  };

  useEffect(() => {
    getData();
  }, []);
  const getData = async () => {
    const result = await axios.get(
      `http://localhost:8090/api/test/getfeebackby/${id}`
    );
    fetchfeedback(result.data);
  };

  const { description, feedbackid, feedbackDate, comments, rating } = feedback;
  return (
    <>
      <h3 style={{ textAlign: "center" }}>Add New Feedback</h3>
      <form>
        <div className="row justify-content-md-center">
          <div className="col ">
            <br />
            <div className="row">
              <input
                className="col"
                type="text"
                placeholder="Rating "
                name="rating"
                variant="outlined"  
                 onChange={e => onInputChange(e)} 
                 value={rating}
              />
              <input
                className="col"
                type="text"
                placeholder="Comments "
                name="comments"
                variant="outlined"
                onChange={e => onInputChange(e)}
                value={comments}
              />
              <input
                className="col"
                type="text"
                placeholder="Description"
                name="description"
                variant="outlined"
                onChange={e => onInputChange(e)}
                value={description}
              />
            </div>
          </div>
        </div>
        <div class="text-center" id="btns">
          <button type="button" class="btn btn-primary" onClick={e => onSubmit(e)}>
            Add Feedback
          </button>
        </div>
      </form>

      <div>
        <h3 style={{ textAlign: "center" }}>Feedback List</h3>
        <table className="table table-striped">
          <thead className="thead-dark">
            <tr>
              <th scope="col">Feedback Id</th>
              <th scope="col">Feedback Date</th>
              <th scope="col">Description</th>
              <th scope="col"> Rating </th>
              <th scope="col"> Reply By Admin</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>{feedbackid}</td>
              <td>{feedbackDate} </td>
              <td>{description}</td>
              <td>{rating}</td>
              <td>{comments}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </>
  );
}
