import React, { Component } from "react";
import axios from "axios";
import authHeader from "../services/auth-header";
export default class Registration extends Component {

  constructor(props) {
    super(props);
    var today = new Date(),date = today.getFullYear() + "-"+"0" +(today.getMonth() + 1) + "-" + today.getDate();
    var today2 = new Date(),date2 =today2.getFullYear() +"-" +"0" +(today2.getMonth() + 1) +"-" + today2.getDate();
    this.state = {
      date: date,
      dat: date2,
      role: ["mod", "mod"],
      password: "",
      username: "",
      lastName: "",
      mobileno: "",
      email: "",
      date_of_birth: "",
      subscription_status: "Acitve",
      subscription_date: date,
      sub_expire_date: date2,
    };
  }


handleSubmit = (e) => {
  e.preventDefault();
  console.log(this.state);
  axios.post("http://localhost:8090/api/auth/signup", { headers: authHeader() })
  .then((res) => {
    alert("Registered Succesfully");
    this.props.history.push("/login");
    console.log("User Registered");
  })
    .catch((error) => {});
  };


  handler = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  render() {
    return (
      <>
        <div className="regi" id="regimg">
          <form>
            <h3 style={{textAlign: "center",marginBottom: "30px",}}>
              Sign up
            </h3>

            <div className="row" id="roww">
              <input
                className="form-control"
                required={true}
                type="text"
                style={{ marginBottom: "9px" }}
                placeholder="User Name "
                pattern="[A-za-z]{3,}"
                value={this.state.username}
                name="username"
                onChange={this.handler}
              />

              <input
                className="form-control"
                required={true}
                type="text"
                style={{ marginBottom: "9px" }}
                placeholder="Surname "
                pattern="[A-za-z]{3,}"
                value={this.state.lastName}
                name="lastName"
                onChange={this.handler}
              ></input>

              <input
                className="form-control"
                required={true}
                style={{ marginBottom: "9px" }}
                type="email"
                placeholder=" Email"
                value={this.state.email}
                name="email"
                onChange={this.handler}
              />

              <input
                className="form-control"
                required={true}
                type="text"
                style={{ marginBottom: "9px" }}
                placeholder="Mobile No "
                pattern="[0-9]{10}"
                value={this.state.mobileno}
                name="mobileno"
                onChange={this.handler}
              />
              <label style={{color:"white"}}>Date Of Birth</label>
              <input
                className="form-control"
                required={true}
                type="date"
                placeholder=" Date Of Birth"
                value={this.state.date_of_birth}
                name="date_of_birth"
                style={{ marginBottom: "9px" }}
                onChange={this.handler}
              />

              <input
                className="form-control"
                required={true}
                type="password"
                placeholder=" Password"
                pattern=".{8,}"
                title="Enter More than 8 Char"
                value={this.state.password}
                name="password"
                onChange={this.handler}
              />

              <button id="bt"onClick={this.handleSubmit} class="btn btn-success">Submit</button>
              <button class="btn btn-danger" onClick={this.reset} id="bt">Reset</button>

            </div>
          </form>
        </div>
      </>
    );
  }
}
