import React, { Component } from 'react'

import axios from "axios";
import authHeader from "../services/auth-header";

export default class SuggestedBooks extends Component {

constructor(props){
    super(props);
    this.state={
        m:[],
    };
}
    componentDidMount() {
        axios
          .get("http://localhost:8090/api/test/getSuggestedBooks", { headers: authHeader() })
          .then((response) => {
            this.setState({ m: response.data });
          });
        }


        reject = (id) => {
            axios
              .delete("http://localhost:8090/api/test/deleteSuggestedBooks/" + id, {
                headers: authHeader(),
              })
              .then(
                (response) => {
                  alert("Rejected");
                  window.location.reload(false);
                },
                (error) => {
                  window.location.reload(false);
                  alert("Operation failed");
                }
              );
          };
          accept = (id) => {
            axios
              .put("http://localhost:8090/api/test/updateSuggestedBook/" + id, {
                headers: authHeader(),
              })
              .then(
                (response) => {
                  alert("Accepted");
                  window.location.reload(false);
                },
                (error) => {
                  window.location.reload(false);
                  alert("Operation failed");
                }
              );
          };
  render() {
    return (
     <>
     
     <div>
     <h3 style={{textAlign:"center"}}>Suggestd Books</h3>
            <table className="table table-striped">
              <thead class="table-success">
                <tr>
                  <th scope="col">Book Id</th>
                  <th scope="col">Title</th>
                  <th scope="col">Subject</th>
                  <th scope="col"> Author </th>
                  <th scope="col"> Publications </th>
                  <th scope="col">Description </th>
                  <th scope="col">Date </th>
                  <th scope="col"> Status </th>
                  <th scope="col"> Accept </th>
                  <th scope="col"> Reject</th>
                </tr>
              </thead>
              <tbody>
                {this.state.m.map((c) => (
                  <tr key={c.id}>
                    <td>{c.id}</td>
                    <td>{c.title} </td>
                    <td>{c.subject}</td>
                    <td>{c.author}</td>
                    <td>{c.publications}</td>
                    <td>{c.description}</td>
                    <td>{c.suggested_date}</td>
                    <td>{c.status}</td>
                    <td>
                      <button
                        type="button"
                        class="btn btn-primary "
                        onClick={() => {
                          this.accept(c.id);
                        }}
                      >
                        Accept
                      </button>
                    </td>
                    <td>
                      <button
                        type="button"
                        class="btn btn-danger "
                        onClick={() => {
                          this.reject(c.id);
                        }}
                      >
                        Reject
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
     </>
    )
  }
}
