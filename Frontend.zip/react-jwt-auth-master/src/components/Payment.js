import React, { Component } from "react";
import axios from "axios";
import authHeader from "../services/auth-header";
import { Link } from "react-router-dom";
export default class Payment extends Component {
  constructor(props) {
    super(props);
    this.state = {
        type:"",
     cardNumber: "",
        cardName: "",
        cardType: "",
      package: "",
      expiryDate:"",
      AllPackages: [],
    };
  }

  componentDidMount() {
    axios
      .get("http://localhost:8090/api/packages/viewAllPackages", {
        headers: authHeader(),
      })
      .then((response) => {
        this.setState({ AllPackages: response.data });
      });
  }

  handleSubmit = (e) => {
    e.preventDefault();
    console.log(this.state);
    axios
      .post("http://localhost:8090/api/payment/makePayment/1", this.state, {
        headers: authHeader(),
      })
      .then((res) => {
        alert("Added Succesfully");
        window.location.reload(false);
      })
      .catch((error) => {});
  };

  handler = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  deletebook = (packageId) => {
    axios
      .delete("http://localhost:8090/api/booking/deleteBooking/" + packageId, {
        headers: authHeader(),
      })
      .then(
        (response) => {
          alert("Package Deleted");
          window.location.reload(false);
        },
        (error) => {
          window.location.reload(false);
          alert("Operation failed");
        }
      );
  };
  package = (e) => {
    this.setState({ package: e.target.value });
  };
  render() {
    return (
      <div>
        <h3 style={{ textAlign: "center" }} id="bookback">
          Add Card Details
        </h3>
        <div className="regi">
          <form>
            <div className="row">
              <div className="col">
                <input
                  style={{ marginBottom: "9px" }}
                  type="text"
                  className="form-control"
                  placeholder="type  "
                  value={this.state.type}
                  name="type"
                  onChange={this.handler}
                />
                <input
                  style={{ marginBottom: "9px" }}
                  type="text"
                  className="form-control"
                  placeholder="cardType "
                  value={this.state.cardType}
                  name="cardType"
                  onChange={this.handler}
                />
                <input
                  style={{ marginBottom: "9px" }}
                  type="text"
                  className="form-control"
                  placeholder=" cardName "
                  value={this.state.cardName}
                  name="cardName"
                  onChange={this.handler}
                />

                <div>
                  <label for="publishers" id="opt">
                    {" "}
                    Available Packages
                  </label>
                  <select
                    onChange={this.package}
                    id="packageName"
                    className="form-control"
                  >
                    {this.state.AllPackages.map((o) => (
                      <option value={o.packageName}>{o.packageName}</option>
                    ))}
                  </select>
                </div>

                <input
                  style={{ marginBottom: "9px" }}
                  type="Number"
                  className="form-control"
                  placeholder=" cardNumber "
                  value={this.state.cardNumber}
                  name="cardNumber"
                  onChange={this.handler}
                />
                <input
                  style={{ marginBottom: "9px" }}
                  type="date"
                  className="form-control"
                  placeholder=" expiryDate "
                  value={this.state.expiryDate}
                  name="expiryDate"
                  onChange={this.handler}
                />
                <input
                  style={{ marginBottom: "9px" }}
                  type="Number"
                  className="form-control"
                  placeholder=" cvv "
                  value={this.state.cvv}
                  name="cvv"
                  onChange={this.handler}
                />
              </div>
            </div>
            <div class="text-center" id="btns">
              <button
                type="button"
                class="btn btn-primary "
                onClick={this.handleSubmit}
              >
                Pay
              </button>
            </div>
          </form>
        </div>
        <div>
          <div>
            <table className="table table-striped">
              <thead class="table-primary">
                <tr>
                  <th scope="col">Package Id</th>
                  <th scope="col">Package Name</th>
                  <th scope="col">Fare</th>
                  <th scope="col"> Update</th>
                  <th scope="col"> Delete</th>
                </tr>
              </thead>
              <tbody>
                {this.state.AllPackages.map((pkg) => (
                  <tr key={pkg.packageId}>
                    <td>{pkg.packageId}</td>
                    <td>{pkg.packageName}</td>

                    <td>{pkg.description} </td>
                    <td>{pkg.fare}</td>
                    <td>
                      <button
                        type="button"
                        class="btn btn-danger "
                        onClick={() => {
                          this.deletebook(pkg.packageId);
                        }}
                      >
                        Remove Package
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }
}
