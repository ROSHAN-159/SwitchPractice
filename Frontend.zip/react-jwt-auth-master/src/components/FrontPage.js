// import React from 'react'

// function FrontPage() {
//   return (
//    <>

// <div  id="demo" className="carousel slide" data-ride="carousel" style={{margintop: "80px",float: "left",width: "100%"}} >
//   <ul className="carousel-indicators">
//     <li data-target="#demo" data-slide-to="0" className="active"></li>
//     <li data-target="#demo" data-slide-to="1"></li>
//     <li data-target="#demo" data-slide-to="2"></li>
//   </ul>
//   <div className="carousel-inner" style={{ align:"center"}}>
//     <div className="carousel-item active">
//       <img src="image/lab2.jpg" alt="Los Angeles"style={{ width:"1100", heightp:"500"}}/>
//       <div className="carousel-caption" style={{color: "white"}} >
//         <h1 style={{fontFamily:"Heiti SC" }}>Library Management System</h1>
//        <h1 style={{fontFamily:"Apple Chancery",fontSize:"100%",opacity:"0.8"}}>Learning Gives Creativity.Creativity Leads To Thinking.<br>Thinking Provides Knowledge.Knowledge Makes You Great <br>-Dr.Abdul Kalam</h1>
//       </div>   
//     </div>
//     <div className="carousel-item" style={{ align:"center"}}>
//       <img src="image/lab3.jpg" alt="Chicago" style={{ width:"1100", height:"500"}}/>
//       <div className="carousel-caption">
       
//       </div>   
//     </div>
//     <div className="carousel-item" style={{ align:"center"}}>
//       <img src="image/lab0.jpg" alt="New York" style={{width:"1100", height:"100"}}/>
//       <div className="carousel-caption">
//           <h1 style={{fontFamily:"Apple Chancery",fontSize:"100%",opacity:"0.8"}}>"I have always imagined that Paradise will be a kind of a Library."<br>Jorge Luis Borges <br>(1899-1986. Argentine writer)</h1>
//       </div>   
//     </div>
//   </div>
//   <p className="carousel-control-prev" href="#demo" data-slide="prev"/>
//    Prev
//     <span className="carousel-control-prev-icon"></span>
//   </p>
//   <a className="carousel-control-next" href="#demo" data-slide="next">
//     Next
//     <span className="carousel-control-next-icon"></span>
//   </a>
// </div>
// </div>
// <div className="footer-dark">
//     <footer>
//         <div className="container">
//             <div className="row">
//                 <div className="col-sm-6 item">
//                     <h3 id="team">Team</h3>
//                     <ul>
//                         <li>Roshan</li>
//                         <li>Jay</li>
//                         <li>Piyush</li>
//                         <li>Prajakta</li>
//                         <li>Manali</li>
//                         <li>Deepti</li>
//                     </ul>
//                 </div>
//              <div className="col-sm-6 col-md-3 item">
//                      <h3>About</h3>
//                   <ul>
//                         <li><a href="#">Prajakta</a></li>
//                         <li><a href="#">Manali</a></li>
//                         <li><a href="#">Deepti</a></li>
//                     </ul>
//                 </div>
//                 <div className="col-md-6 item text">
//                     <h3>LMS</h3>
//                     {/* <p>LMS is an automated library system software that has been developed to handle basic housekeeping functions of a library.<br>It help to provide information on any book present in library to the users.It keeps a track of book issued, returned and added to library.</p> */}
//                 </div>
//                 <div className="col item social">
//                     <a href="#"><i className="icon ion-social-facebook"></i></a>
//                     <a href="#"><i className="icon ion-social-github"></i></a>
//                     <a href="#"><i className="icon ion-social-linkedin"></i></a>
//                     <a href="#"><i className="icon ion-social-instagram"></i></a>
//                 </div>
//             </div>
//             <p className="copyright">LMS © 2022 All copyright reserved</p>
//         </div>
//     </footer>
// </div>


//    </>
//   )
// }

// export default FrontPage