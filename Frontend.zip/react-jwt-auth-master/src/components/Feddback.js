import React, { Component } from 'react'

import axios from "axios";
import authHeader from "../services/auth-header";
import { Link } from 'react-router-dom';
export default class Feddback extends Component {
  constructor(props){
    super();
    this.state ={
        feedback:[],
    };
  }
  
    componentDidMount() {
        axios
          .get("http://localhost:8090/api/test/getfeedback", {
            headers: authHeader(),
          })
          .then((response) => {
            this.setState({ feedback: response.data });
          });
      }
  
    render() {
    return (
      <>
       <div>
       <h3 style={{textAlign:"center"}}>Feedback List</h3>
            <table className="table table-striped">
              <thead className="thead-dark">
                <tr>
                <th scope="col">Feedback Id</th>
                  <th scope="col">Feedback Date</th>
                  <th scope="col">Description</th>
                  <th scope="col"> Rating </th>
                  <th scope="col"> Comments</th>
                  <th>Add Comment</th>
                </tr>
              </thead>
              <tbody>
                {this.state.feedback.map((c) => (
                  
                  <tr key={c.feedbackid}>
                    <td>{c.feedbackid}</td>
                <td>{c.feedbackDate} </td>
                <td>{c.description}</td>
                <td>{c.rating}</td>
                <td>{c.comments}</td>
                  <td>
                    <Link  className="btn btn-info " to={`/addreply/${c.feedbackid}`}>Reply</Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
      
      
      </>
    )
  }
}
