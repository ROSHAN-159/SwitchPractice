import React, { Component } from "react";
import axios from "axios";
import authHeader from "../services/auth-header";
import AuthService from "../services/auth.service";

export default class UserMenu extends Component {
  constructor(props) {
    super(props);
    this.state = {
      orderDate: "",
      orderStatus: "",
      quantity: 1,
      m: [],
      currentUser: { currentUser: "" },
    };
  }

  componentDidMount() {
    const currentUser = AuthService.getCurrentUser();

    if (!currentUser) this.setState({ redirect: "/home" });
    this.setState({ currentUser: currentUser, userReady: true });

    axios
      .get("http://localhost:8090/api/test/getbooks", { headers: authHeader() })
      .then((response) => {
        this.setState({ m: response.data });
      });
  }

  orderbook = ([orderid, id]) => {
    console.log(this.state);
    console.log(orderid);
    console.log(id);

    axios
      .post(
        `http://localhost:8090/api/test/postorderbooks/${orderid}/${id}`,
        {
          headers: authHeader(),
        },
        this.state
      )
      .then((res) => {
        alert("Order Succesfully");
        window.location.reload(false);
        console.log("Ordered");
      })
      .catch((error) => {
        alert("Operation failed");
      });
  };

  render() {
    const { currentUser } = this.state;
    return (
      <div className="container my-4"  id="imgbook">
        <div className="row">
          {this.state.m.map((element) => {
            return (
              
              <div className="col-md-3" key={element.id}>
                <div className="card">
                <div className="card-body">
                  <h4 className="card-title">{element.title} </h4>
                  <p className="card-subtitle mb-1 text-muted">
                    Author : {element.author}{" "}
                  </p>
                  <p className="card-subtitle mb-1 text-muted">
                    {element.publisher}
                  </p>
                  <h6>Quantity :{element.quantity}</h6>
                  <button
                    type="btn"
                    className="btn btn-primary"
                    onClick={() => {
                      this.orderbook([element.bookid, currentUser.id]);
                    }}
                    style={{marginLeft:"80px",marginBottom:"-30px",marginTop:"20px"}}>
                    Order
                  </button>
                    </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }
}
