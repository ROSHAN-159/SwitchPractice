import React, { Component } from "react";
import { Switch, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import Footer from "./components/Footer"
import DashBoard from "./components/DashBoard";
import Users from "./components/Users";
import SugestBook from "./components/SugestBook";
import AuthService from "./services/auth.service";
import Login from "./components/login.component";
import Home from "./components/home.component";
import Profile from "./components/profile.component";
import EventBus from "./common/EventBus";
import Registration from "./components/Registration";
import AdminMenus from "./components/AdminMenus";
import Books from "./components/Books";
import DamagedBooks from "./components/DamagedBooks";
import UpdateBook from "./components/UpdateBook";
import Order from "./components/Order";
import imgg from "./image/logo.png"
import Publisher from "./components/Publisher";
import SuggestedBooks from "./components/SuggestedBooks";
import Feddback from "./components/Feddback";
import AddReply from "./components/AddReply";
import UserMenu from "./components/UserMenu";
import Author from "./components/Author";
import IssuedBook from "./components/IssuedBooks";
import UserFeedback from "./components/UserFeedback";
import Rkk from "./components/Rkk";
import SearchBook from "./components/SearchBook";
import sample from "./components/sample";
import PackageManaegment from "./components/PackageManaegment";
import Payment from "./components/Payment";
import WorkingMode from "./components/WorkingMode";
class App extends Component {
  constructor(props) {
    super(props);
    this.logOut = this.logOut.bind(this);

    this.state = {
      showAdminBoard: false,
      showModeratorBoard: false,
      currentUser: undefined,
    };
  }

  componentDidMount() {
    const user = AuthService.getCurrentUser();

    if (user) {
      this.setState({
        currentUser: user,
        showModeratorBoard: user.roles.includes("ROLE_MODERATOR"),
        showAdminBoard: user.roles.includes("ROLE_ADMIN"),
      });
    }

    EventBus.on("logout", () => {
      this.logOut();
    });
  }

  componentWillUnmount() {
    EventBus.remove("logout");
  }

  logOut() {
    AuthService.logout();
    this.setState({
      showAdminBoard: false,
      showModeratorBoard: false,
      currentUser: false,
    });
  }

  render() {
    const { currentUser, showAdminBoard, showModeratorBoard } = this.state;

    return (
      <>
      <div>
        <nav className="navbar navbar-expand navbar-dark bg-dark">
          <Link to={"/"} className="navbar-brand">
          <img src={imgg} style={{width:"40px",margin:"0px 5px 10px 10px"}} alt="logo"/>
            Lms
          </Link>
          <div className="navbar-nav mr-auto">
            {showAdminBoard && (
              <li className="nav-item">
                <Link to={"/admin-menus"} className="nav-link">
                  Admin Board
                </Link>
              </li>
            )}
            {showModeratorBoard && (
              // <li className="nav-item">
                <div className="navbar-nav mr-auto">
                {/* <Link to={"/searchbook"} className="nav-link">
                  SearchBook
                </Link> */}
      <li><Link className="nav-link active" to="/usermenu">Books</Link></li>
      <li><Link className="nav-link active" to={`/userfeedback/${currentUser.id}`}>Feedback</Link></li>
      <li><Link className="nav-link active" to="/issuedbooks">Issued Books</Link></li>
      <li><Link className="nav-link active" to="/workingmode">Working Mode</Link></li>
      <li><Link className="nav-link active" to="/sugestbook">Suggest Book </Link></li>
 
  </div>
              // </li>
             )}
             </div>
             
             

          {currentUser ? (
            <div className="navbar-nav ml-auto">
              <li className="nav-item">
                <Link to={"/profile"} className="nav-link">
                  {currentUser.username.charAt(0).toUpperCase() +
                    currentUser.username.slice(1)}
                </Link>
              </li>
              <li className="nav-item">
                <a href="/login" className="nav-link" onClick={this.logOut}>
                  LogOut
                </a>
              </li>
            </div>
          ) : (
            <div className="navbar-nav ml-auto">
              <li className="nav-item">
                <Link to={"/login"} className="nav-link">
                  Login
                </Link>
              </li>
              <li className="nav-item">
                <Link to={"/registration"} className="nav-link">
                  Sign Up
                </Link>
              </li>
            </div>
          )}
        </nav>

        <div className="container mt-3">
          <Switch>
            <Route exact path={["/", "/home"]} component={Home} />
            <Route exact path="/login" component={Login} />
            <Route exact path="/registration" component={Registration} />
            <Route exact path="/admin-menus" component={AdminMenus} />
            <Route exact path="/profile" component={Profile} />
            <Route exact path="/users" component={Users} />
            <Route exact path="/books" component={Books} />
            <Route exact path="/damagedbooks" component={DamagedBooks} />
          /
            <Route exact path="/order" component={Order} />
            <Route exact path="/publisher" component={Publisher} />
            <Route exact path="/suggestedbooks" component={SuggestedBooks} />
            <Route exact path="/sugestbook" component={SugestBook} />
            <Route exact path="/feedback" component={Feddback} />
            <Route exact path="/dashboard" component={DashBoard} />
            <Route exact path="/usermenu" component={UserMenu} />
            <Route exact path="/author" component={Author} />
            <Route exact path="/issuedbooks" component={IssuedBook} />
            <Route exact path="/addreply/:id" component={AddReply} />
            <Route exact path="/userfeedback/:id" component={UserFeedback} />
            <Route exact path="/searchbook" component={SearchBook} />
            <Route exact path="/packagemanaegment" component={PackageManaegment} />
            <Route exact path="/payment" component={Payment} />
            <Route exact path="/workingmode" component={WorkingMode} />
            
            <Route exact path="/sample" component={sample} />
          </Switch>
        </div>
      </div>
      <footer id="foter">
        <Footer/>
      </footer>
      </>
    );
  }
}

export default App;
