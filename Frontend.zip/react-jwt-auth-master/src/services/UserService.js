import axios from "axios";
import authHeader from "./auth-header";
const UserUrl = "http://localhost:8080/api/users/";
class UserService {
    deleteusers(id){
        return axios.delete(UserUrl + id, { headers: authHeader()});
    }
 
}
export default new UserService()